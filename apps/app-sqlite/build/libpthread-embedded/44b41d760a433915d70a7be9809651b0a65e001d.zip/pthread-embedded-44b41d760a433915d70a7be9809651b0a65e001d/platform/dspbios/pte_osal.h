
#ifndef _OS_SUPPORT_H_
#define _OS_SUPPORT_H_

// Platform specific one must be included first
#include "dspbios-osal.h"

#include "pte_generic_osal.h"



#endif // _OS_SUPPORT_H
