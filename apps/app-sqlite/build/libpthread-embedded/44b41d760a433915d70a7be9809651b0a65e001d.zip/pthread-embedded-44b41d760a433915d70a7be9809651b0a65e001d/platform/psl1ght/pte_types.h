/* pte_types.h  */

#ifndef PTE_TYPES_H
#define PTE_TYPES_H

#include <errno.h>
#include <sys/types.h>
#include <sys/timeb.h>

typedef int pid_t;

#endif /* PTE_TYPES_H */
